 
package POJO;


public class RegisterBean    {
       
   
      private String fullName;
      private String status;
      private String role;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

   private String skill;

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }
   private String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
   
    private String qualification;

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
    private int age;
    private int pin;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
   private String city;
   

    public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public int getPin() {
	return pin;
}

public void setPin(int pin) {
	this.pin = pin;
}

	public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
 private String email;
 private String userName;
 private String password; 
 
}
